package Zadatak3;

/**
 *
 * @author student
 */
public class BST {

    BinaryNode root;

    public BST() {

    }

    public BinaryNode getRoot() {
        return root;
    }

    public void setRoot(BinaryNode root) {
        this.root = root;
    }

    public void addToRoot(int value) {
        if (root == null) {
            root = new BinaryNode(value);
        } else {
            add(root, value);
        }

    }

    public void add(BinaryNode current, int value) {

        if (value < current.getValue()) {
            if (current.getLeft() == null) {
                current.setLeft(new BinaryNode(value));
            } else {
                add(current.getLeft(), value);
            }
        } else if (current.getRight() == null) {
            current.setRight(new BinaryNode(value));
        } else {
            add(current.getRight(), value);
        }

    }

    //INORDER
    public void print(BinaryNode current) {

        if (current == null) {
            return;
        }

        print(current.getLeft());
        System.out.println(current.getValue());
        print(current.getRight());

    }

    //da li element postoji u binarnom stablu pretrage (BST)
    public boolean pretraga(int element) {

        return pretraga(root, element);

    }

    public boolean pretraga(BinaryNode r, int element) {

        boolean pronadjen = false;

        while ((r != null) && !pronadjen) {

            int vrednost = r.value;
            if (element < vrednost) {
                r = r.left;
            } else if (element > vrednost) {
                r = r.right;
            } else {
                pronadjen = true;
                break;

            }

            pronadjen = pretraga(r, element);

        }
        return pronadjen;
    }

}
