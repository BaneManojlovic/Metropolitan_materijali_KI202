/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Zadatak3;

/**
 *
 * @author student
 */
public class BinaryNode {
    protected int value;
    protected BinaryNode left;
    protected BinaryNode right;

    public BinaryNode(int value) {
        this.value = value;
        left = null;
        right = null;
    }
    
    

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public BinaryNode getLeft() {
        return left;
    }

    public void setLeft(BinaryNode left) {
        this.left = left;
    }

    public BinaryNode getRight() {
        return right;
    }

    public void setRight(BinaryNode right) {
        this.right = right;
    }

 
    
    
}