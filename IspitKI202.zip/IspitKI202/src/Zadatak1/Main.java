/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Zadatak1;


public class Main {
    
    public static void main(String[] args) {
        
        List lista = new List();
         lista.add(5);
         lista.add(6);
         lista.add(7);
        
         System.out.println(lista.min());
    }
    
}
