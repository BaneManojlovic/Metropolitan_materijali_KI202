
package Zadatak1;

public class List {
    Node first;
    
    public void add(int value){
        
        if(first == null){
            first = new Node(value);
            return;
        }
        
        Node tmp = first;
        for(; tmp.getNext() != null; tmp = tmp.getNext()){
            
        }
        tmp.setNext(new Node(value));
    }
    
    public void print(Node current){
        if(current == null){
            return;
        }
        System.out.println(current.getValue());
        print(current.getNext());
    }
    
    public void printIterative(){
        for(Node tmp = first; tmp!= null; tmp = tmp.getNext()){
            System.out.println(tmp.getValue());
        }
    }
    
    public boolean contains(int e){
        for(Node tmp = first; tmp!= null; tmp = tmp.getNext()){
            if(e == tmp.getValue()){
                return true;
            }            
        }
        return false;
    }
    
    
    //metoda za minimum
    public int min(){
        Node min = first;
        for(Node tmp = min.getNext(); tmp!= null; tmp = tmp.getNext()){
            if(min.getValue() > tmp.getValue()){
                min = tmp;
            }            
        }
        return min.getValue();
    }
    
    
}

