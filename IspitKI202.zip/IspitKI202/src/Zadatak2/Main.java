/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Zadatak2;

/**
 *
 * @author student
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         BST bst = new BST();
        bst.addToRoot(5);
        bst.addToRoot(45);
        bst.addToRoot(2);
        bst.addToRoot(1);
        bst.addToRoot(6);
        
        System.out.println(bst.prebroj(bst.getRoot()));
    }
    
}
