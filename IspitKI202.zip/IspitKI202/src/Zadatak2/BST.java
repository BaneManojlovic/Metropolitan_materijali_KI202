
package Zadatak2;

/**
 *
 * @author student
 */
public class BST {

    BinaryNode root;

    public BST() {

    }

    public BinaryNode getRoot() {
        return root;
    }

    public void setRoot(BinaryNode root) {
        this.root = root;
    }

    public void addToRoot(int value) {
        if (root == null) {
            root = new BinaryNode(value);
        } else {
            add(root, value);
        }

    }

    public void add(BinaryNode current, int value) {

        if (value < current.getValue()) {
            if (current.getLeft() == null) {
                current.setLeft(new BinaryNode(value));
            } else {
                add(current.getLeft(), value);
            }
        } else if (current.getRight() == null) {
            current.setRight(new BinaryNode(value));
        } else {
            add(current.getRight(), value);
        }

    }

    //INORDER
    public void print(BinaryNode current) {

        if (current == null) {
            return;
        }

        print(current.getLeft());
        System.out.println(current.getValue());
        print(current.getRight());

    }

    
    //prebrojava parne
    public int prebroj(BinaryNode current) {

        if (current == null) {
            return 0;
        }

        if (current.getValue() % 2 == 0) {
            return 1 + prebroj(current.getLeft()) + prebroj(current.getRight());

        } else {
            return prebroj(current.getLeft()) + prebroj(current.getRight());
        }

    }

}
